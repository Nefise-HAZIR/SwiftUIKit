//
//  KisilerDaoRepository.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift

class PersonsDaoRepository {
    var personlsList=BehaviorSubject<[Persons]>(value: [Persons]())
    let db:FMDatabase?
    
    init( ){
        let hedefYolu=NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        
        let veriTabaniURL = URL(fileURLWithPath: hedefYolu).appendingPathComponent("rehber.sqlite")
        db = FMDatabase(path: veriTabaniURL.path)
    }
    
    func save(person_name:String,person_phone:String){
        db?.open()
        do{
            try db!.executeUpdate("INSERT INTO persons (person_name,person_phone) VALUES (?,?)", values: [person_name,person_phone])
        }catch{
            print(error.localizedDescription)
        }
        db?.close()
    }
    func update(person_id:Int,person_name:String,person_phone:String){
        db?.open()
        do{
            try db!.executeUpdate("UPDATE persons SET person_name = ? , person_phone = ? WHERE person_id = ?", values: [person_name,person_phone,person_id])
        }catch{
            print(error.localizedDescription)
        }
        db?.close()
    }
    func delete (person_id:Int){
        db?.open()
        do{
            try db!.executeUpdate("DELETE FROM persons WHERE person_id = ?", values: [person_id])
            loadPersons()
        }catch{
            print(error.localizedDescription)
        }
        db?.close()
        
    }
    func search(searchText:String){
        db?.open()
        var list=[Persons]()
        do{
            let rs = try db!.executeQuery("SELECT * FROM persons WHERE person_name like '%\(searchText)%' ", values: nil)
            while rs.next(){
                let kisi=Persons(person_id: Int(rs.string(forColumn: "person_id"))!,
                                 person_name: rs.string(forColumn: "person_name")!,
                                 person_phone: rs.string(forColumn: "person_phone")!)
                list.append(kisi)
            }
            personlsList.onNext(list)
        }catch{
            print(error.localizedDescription)
        }
        db?.close()
    }
    
    func loadPersons(){
        db?.open()
        var list=[Persons]()
        do{
            let rs = try db!.executeQuery("SELECT * FROM persons", values: nil)
            while rs.next(){
                let kisi=Persons(person_id: Int(rs.string(forColumn: "person_id"))!,
                                 person_name: rs.string(forColumn: "person_name")!,
                                 person_phone: rs.string(forColumn: "person_phone")!)
                list.append(kisi)
            }
            personlsList.onNext(list)
        }catch{
            print(error.localizedDescription)
        }
        db?.close()
    }
}
