//
//  HomeScreenViewmodel.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift
class HomeScreenViewModel{
    var kRepo=PersonsDaoRepository()
    var personlsList=BehaviorSubject<[Persons]>(value: [Persons]())
    
    init(){
        databaseCopy()
        personlsList=kRepo.personlsList
        kRepo.loadPersons()
    }
    func delete (person_id:Int){
        kRepo.delete(person_id: person_id)
    }
    
    func search(searchText:String){
        kRepo.search(searchText: searchText)
    }
    
    func loadPersons( ){
        kRepo.loadPersons()
    }
    func databaseCopy(){
        let bundleYolu=Bundle.main.path(forResource: "rehber", ofType: ".sqlite")
        let hedefYolu=NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        
        let kopyalanacakYer = URL(fileURLWithPath: hedefYolu).appendingPathComponent("rehber.sqlite")
        
        let fileManager=FileManager.default
        if fileManager.fileExists(atPath: kopyalanacakYer.path){
            print("veri tabanı zaten var")
        }else{
            do{
                try fileManager.copyItem(atPath: bundleYolu!, toPath: kopyalanacakYer.path)
            }catch{
                
            }
        }
    }
    
}
