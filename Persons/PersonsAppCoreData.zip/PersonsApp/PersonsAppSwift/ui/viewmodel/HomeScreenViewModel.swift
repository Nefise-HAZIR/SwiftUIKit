//
//  HomeScreenViewmodel.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift
class HomeScreenViewModel{
    var kRepo=PersonsDaoRepository()
    var personlsList=BehaviorSubject<[PersonsModel]>(value: [PersonsModel]())
    
    init(){
        personlsList=kRepo.personlsList
        kRepo.loadPersons()
    }
    func delete (person:PersonsModel){
        kRepo.delete(person: person)
    }
    
    func search(searchText:String){
        kRepo.search(searchText: searchText)
    }
    
    func loadPersons( ){
        kRepo.loadPersons()
    }
    
}
