//
//  KisilerDaoRepository.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift
import CoreData
class PersonsDaoRepository {
    var personlsList=BehaviorSubject<[PersonsModel]>(value: [PersonsModel]())
    let context=appDelegate.persistentContainer.viewContext
    func save(person_name:String,person_phone:String){
       let person=PersonsModel(context: context)
        person.kisi_ad=person_name
        person.kisi_tel=person_phone
        appDelegate.saveContext()
    }
    func update(person:PersonsModel,person_name:String,person_phone:String){
        person.kisi_ad=person_name
        person.kisi_tel=person_phone
        
        appDelegate.saveContext()
    }
    func delete (person:PersonsModel){
        context.delete(person)
        appDelegate.saveContext()
        loadPersons()
    }
    func search(searchText:String){
        do {
            let fr=PersonsModel.fetchRequest()
            fr.predicate=NSPredicate(format: "kisi_ad CONTAINS[c] %@", searchText)
            let list = try context.fetch(fr)
            personlsList.onNext(list)
        } catch  {
            print(error.localizedDescription)
        }
    }
    
    func loadPersons(){
        do {
            let list = try context.fetch(PersonsModel.fetchRequest())
            personlsList.onNext(list)
        } catch  {
            print(error.localizedDescription)
        }
        
    }
}
