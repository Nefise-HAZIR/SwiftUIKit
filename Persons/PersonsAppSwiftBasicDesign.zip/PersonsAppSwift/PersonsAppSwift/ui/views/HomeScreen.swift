//
//  ViewController.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 27.08.2024.
//

import UIKit

class HomeScreen: UIViewController{
   
    @IBOutlet weak var personsTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var personsList=[Persons]()
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate=self
        personsTableView.delegate=self
        personsTableView.dataSource=self
        
        
        let k1=Persons(person_id: 1, person_name: "Ahmet", person_phone: "1111")
        let k2=Persons(person_id: 2, person_name: "Zeynep", person_phone: "2222")
        let k3=Persons(person_id: 3, person_name: "Mehmet", person_phone: "3333")
        personsList.append(k1)
        personsList.append(k2)
        personsList.append(k3)
    }
    override func viewWillAppear(_ animated: Bool) {
        print("Anasayfaya dönüldü")
    }

    //@IBAction func buttonDetail(_ sender: Any) {
    //    let person=Persons(person_id: 1, person_name: "nefise", person_phone: "1111")
      //  performSegue(withIdentifier: "toDetail", sender: person)
    //}
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="toDetail"{
            if let person=sender as? Persons{
                let gidilecekVC=segue.destination as! PersonDetail
                gidilecekVC.person=person
            }
        }
    }
    
   
    
}

extension HomeScreen :UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print("kişi ara: \(searchText)")
    }
}
extension HomeScreen : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personsList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let person=personsList[indexPath.row]
        
        let hucre=tableView.dequeueReusableCell(withIdentifier: "kisilerHucre")as! KisilerHucre
        
        hucre.labelPersonName.text=person.person_name
        hucre.labePersonPhone.text=person.person_phone
        
        return hucre
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let person=personsList[indexPath.row]
        performSegue(withIdentifier: "toDetail", sender: person)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let deleteAction=UIContextualAction(style: .destructive, title: "Delete"){contextualAction,view,bool in
            let person=self.personsList[indexPath.row]
            let alert=UIAlertController(title: "Silme İşlemi", message: "\(person.person_name!) silinsin mi ?", preferredStyle: .alert)
            let cancelAction=UIAlertAction(title: "İptal", style: .cancel)
            alert.addAction(cancelAction)
            let yesAction=UIAlertAction(title: "Evet", style: .destructive){
                action in
                print("kişi sil : \(person.person_id!)")
            }
            alert.addAction(yesAction)
            self.present(alert, animated: true)
                    }
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}
