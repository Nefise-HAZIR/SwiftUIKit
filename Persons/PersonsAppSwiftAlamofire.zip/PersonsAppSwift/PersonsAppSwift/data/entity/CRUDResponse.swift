//
//  CRUDResponse.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 19.11.2024.
//

import Foundation

class CRUDResponse : Codable {
    var success:Int?
    var message:String?
    
}
