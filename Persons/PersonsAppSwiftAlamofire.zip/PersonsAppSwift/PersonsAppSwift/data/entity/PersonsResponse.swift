//
//  PersonsResponse.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 19.11.2024.
//

import Foundation

class PersonsResponse : Codable{
    var persons:[Persons]?
    var success:Int?
}
