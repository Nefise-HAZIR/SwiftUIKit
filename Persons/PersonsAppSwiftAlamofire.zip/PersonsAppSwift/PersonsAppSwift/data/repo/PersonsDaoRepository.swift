//
//  KisilerDaoRepository.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift
import Alamofire

class PersonsDaoRepository {
    var personlsList=BehaviorSubject<[Persons]>(value: [Persons]())
    
    func save(person_name:String,person_phone:String){
        let params:Parameters = ["kisi_ad":person_name,"kisi_tel":person_phone]
        AF.request("http://kasimadalan.pe.hu/kisiler/insert_kisiler.php",method: .post,parameters: params).response {
            response in
            if let data=response.data{
                do {
                    let response = try JSONDecoder().decode(CRUDResponse.self, from: data)
                    print("baraşı:\(response.success!)")
                    print("mesaj:\(response.message!)")
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }
    }
    func update(person_id:Int,person_name:String,person_phone:String){
        let params:Parameters = ["kisi_id":person_id,"kisi_ad":person_name,"kisi_tel":person_phone]
        AF.request("http://kasimadalan.pe.hu/kisiler/update_kisiler.php",method: .post,parameters: params).response {
            response in
            if let data=response.data{
                do {
                    let response = try JSONDecoder().decode(CRUDResponse.self, from: data)
                    print("baraşı:\(response.success!)")
                    print("mesaj:\(response.message!)")
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }
    }
    func delete (person_id:Int){
        let params:Parameters = ["kisi_id":person_id]
        AF.request("http://kasimadalan.pe.hu/kisiler/delete_kisiler.php",method: .post,parameters: params).response {
            response in
            if let data=response.data{
                do {
                    let response = try JSONDecoder().decode(CRUDResponse.self, from: data)
                    print("baraşı:\(response.success!)")
                    print("mesaj:\(response.message!)")
                    self.loadPersons()
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }
      
    }
    func search(searchText:String){
        let params:Parameters = ["kisi_ad":searchText]
        AF.request("http://kasimadalan.pe.hu/kisiler/tum_kisiler_arama.php",method: .post,parameters: params).response {
            response in
            if let data=response.data{
                do {
                    let response = try JSONDecoder().decode(PersonsResponse.self, from: data)
                    if let list=response.persons{
                        self.personlsList.onNext(list)
                    }
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func loadPersons(){
      
        AF.request("http://kasimadalan.pe.hu/kisiler/tum_kisiler.php",method: .get).response {
            response in
            if let data=response.data{
                do {
                    let response = try JSONDecoder().decode(PersonsResponse.self, from: data)
                    if let list=response.persons{
                        self.personlsList.onNext(list)
                    }
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }
    }
}
