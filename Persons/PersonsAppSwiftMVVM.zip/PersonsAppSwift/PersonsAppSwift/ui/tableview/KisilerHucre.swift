//
//  KisilerHucre.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 27.08.2024.
//

import UIKit

class KisilerHucre: UITableViewCell {

    @IBOutlet weak var labePersonPhone: UILabel!
    @IBOutlet weak var labelPersonName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
