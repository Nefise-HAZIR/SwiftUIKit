//
//  KisilerDaoRepository.swift
//  PersonsAppSwift
//
//  Created by Nefise Hazır on 1.10.2024.
//

import Foundation
import RxSwift

class PersonsDaoRepository {
    var personlsList=BehaviorSubject<[Persons]>(value: [Persons]())
    
    func save(person_name:String,person_phone:String){
        print("kişi kaydet: \(person_name) \(person_phone)")
    }
    func update(person_id:Int,person_name:String,person_phone:String){
        print("kişi kaydet:\(person_id) \(person_name) \(person_phone)")
    }
    func delete (person_id:Int){
        print("kişi sil : \(person_id)")
        loadPersons()
    }
    func search(searchText:String){
        print("kişi ara: \(searchText)")
    }
    
    func loadPersons(){
        var list=[Persons]()
        let k1=Persons(person_id: 1, person_name: "Ahmet", person_phone: "1111")
        let k2=Persons(person_id: 2, person_name: "Zeynep", person_phone: "2222")
        let k3=Persons(person_id: 3, person_name: "Mehmet", person_phone: "3333")
        list.append(k1)
        list.append(k2)
        list.append(k3)
        personlsList.onNext(list)
    }
}
